import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), 'nutrilens.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Users Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Health Profiles Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS health_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            age INTEGER,
            gender TEXT,
            diet_type TEXT,
            medical_conditions TEXT,
            allergies TEXT,
            health_goals TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    # Additives Database Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS additives_db (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code_name TEXT UNIQUE NOT NULL,
            common_name TEXT NOT NULL,
            category TEXT NOT NULL,
            risk_level TEXT NOT NULL, -- Low, Moderate, High, Critical
            health_risks TEXT NOT NULL,
            fda_status TEXT,
            efsa_status TEXT
        )
    ''')

    # Scans History Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_name TEXT,
            image_filename TEXT,
            extracted_text TEXT,
            health_score INTEGER NOT NULL,
            risk_category TEXT NOT NULL, -- Safe, Moderate, Red Flag
            deceptive_claims TEXT, -- JSON or string
            detected_additives TEXT, -- JSON or string
            detected_allergens TEXT, -- JSON or string
            recommendations TEXT,
            scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    # Insert default admin if not exists
    cursor.execute("SELECT * FROM users WHERE email = 'admin@nutrilens.ai'")
    admin = cursor.fetchone()
    if not admin:
        admin_pass = generate_password_hash("admin123")
        cursor.execute(
            "INSERT INTO users (name, email, password, is_admin) VALUES (?, ?, ?, 1)",
            ("System Admin", "admin@nutrilens.ai", admin_pass)
        )

    # Insert sample seed additives into additives_db
    seed_additives = [
        ("E621", "Monosodium Glutamate (MSG)", "Flavor Enhancer", "Moderate", "Can trigger headaches, flushing, sweating, and numbness in sensitive individuals. May stimulate appetite unnaturally.", "Approved with limits", "Approved with limits"),
        ("E102", "Tartrazine (Yellow 5)", "Artificial Color", "High", "Linked to hyperactivity in children, asthma flares, thyroid tumors, and allergic reactions.", "Approved", "Requires warning label in EU"),
        ("E211", "Sodium Benzoate", "Preservative", "High", "When combined with Vitamin C (ascorbic acid), it can form Benzene, a known carcinogen. Linked to ADHD in children.", "Approved with limits", "Approved with limits"),
        ("E320", "Butylated Hydroxyanisole (BHA)", "Antioxidant / Preservative", "Critical", "Reasonably anticipated to be a human carcinogen by US NTP. Known endocrine disruptor affecting hormone levels.", "Approved with limits", "Restricted"),
        ("E321", "Butylated Hydroxytoluene (BHT)", "Antioxidant / Preservative", "High", "Toxic to liver and kidneys at high doses. Potential endocrine disruptor.", "Approved", "Restricted"),
        ("E250", "Sodium Nitrite", "Preservative / Color Fixative", "Critical", "Forms nitrosamines in the stomach during meat digestion, strongly linked to colorectal and stomach cancers.", "Approved with strict limits", "Restricted"),
        ("HFCS", "High Fructose Corn Syrup", "Refined Sweetener", "High", "Rapidly metabolized by liver leading to Non-Alcoholic Fatty Liver Disease, insulin resistance, type-2 diabetes, and obesity.", "GRAS (Generally Recognized as Safe)", "Unrestricted"),
        ("E951", "Aspartame", "Artificial Sweetener", "Moderate", "Categorized as 'possibly carcinogenic' by WHO IARC (Group 2B). May trigger migraines and alter gut microbiome.", "Approved", "Approved"),
        ("E955", "Sucralose", "Artificial Sweetener", "Moderate", "Can alter gut microbiota diversity and produce toxic chloropropanols when heated.", "Approved", "Approved"),
        ("E129", "Allura Red AC (Red 40)", "Artificial Color", "High", "Associated with hyperactive behavior in children, allergic reactions, and gut inflammation.", "Approved", "Requires warning label"),
        ("E133", "Brilliant Blue FCF (Blue 1)", "Artificial Color", "Moderate", "Can cross blood-brain barrier in high doses; linked to mild allergic hypersensitivity.", "Approved", "Approved"),
        ("E220", "Sulfur Dioxide", "Preservative", "High", "Triggers severe asthmatic attacks, bronchospasm, and digestive distress in sensitive individuals.", "Approved with warnings", "Requires mandatory labeling"),
        ("E407", "Carrageenan", "Thickener / Stabilizer", "High", "Degraded carrageenan causes intestinal inflammation, ulcerations, and glucose intolerance.", "Approved", "Restricted in infant formula"),
        ("E433", "Polysorbate 80", "Emulsifier", "Moderate", "Disrupts gut mucosal barrier, promoting low-grade intestinal inflammation and metabolic syndrome.", "Approved", "Approved"),
        ("E466", "Carboxymethyl Cellulose", "Emulsifier / Thickener", "Moderate", "Alters gut bacteria composition, potentially driving inflammatory bowel disease (IBD).", "Approved", "Approved"),
        ("E950", "Acesulfame Potassium (Ace-K)", "Artificial Sweetener", "Moderate", "Contains methylene chloride, a known carcinogen; long-term safety disputed.", "Approved", "Approved"),
        ("E551", "Silicon Dioxide", "Anti-caking Agent", "Low", "Nanoparticle form may accumulate in liver and spleen; generally safe at low concentrations.", "Approved", "Approved"),
        ("E171", "Titanium Dioxide", "White Pigment", "Critical", "Banned in the European Union due to genotoxicity concerns (DNA damage).", "Approved", "BANNED by EFSA (2022)")
    ]

    for code, common, cat, risk, health, fda, efsa in seed_additives:
        cursor.execute('''
            INSERT OR IGNORE INTO additives_db (code_name, common_name, category, risk_level, health_risks, fda_status, efsa_status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (code, common, cat, risk, health, fda, efsa))

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully.")
