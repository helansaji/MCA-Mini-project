import re
import json
import sqlite3
import os
from database import get_db_connection

# Pre-defined list of common harmful additives dictionary for quick fallback
ADDITIVES_DICT = {
    "E621": {"name": "Monosodium Glutamate (MSG)", "risk": "Moderate", "desc": "Excitotoxin linked to headaches, metabolic disruptions, and appetite over-stimulation."},
    "MSG": {"name": "Monosodium Glutamate (MSG)", "risk": "Moderate", "desc": "Flavor enhancer linked to excitotoxicity and increased sodium intake."},
    "E102": {"name": "Tartrazine (Yellow 5)", "risk": "High", "desc": "Artificial dye linked to pediatric hyperactivity, asthma, and thyroid concerns."},
    "E129": {"name": "Allura Red AC (Red 40)", "risk": "High", "desc": "Petroleum-derived dye associated with severe hyperactivity and gut irritation."},
    "E211": {"name": "Sodium Benzoate", "risk": "High", "desc": "Preservative that can combine with Vitamin C to form carcinogenic Benzene."},
    "E250": {"name": "Sodium Nitrite", "risk": "Critical", "desc": "Forms carcinogenic nitrosamines in stomach digestive acid."},
    "E320": {"name": "Butylated Hydroxyanisole (BHA)", "risk": "Critical", "desc": "Endocrine disruptor and anticipated human carcinogen."},
    "E321": {"name": "Butylated Hydroxytoluene (BHT)", "risk": "High", "desc": "Synthetic preservative linked to organ toxicity in animal trials."},
    "HFCS": {"name": "High Fructose Corn Syrup", "risk": "High", "desc": "Drives fatty liver disease, insulin resistance, and visceral obesity."},
    "HIGH FRUCTOSE CORN SYRUP": {"name": "High Fructose Corn Syrup", "risk": "High", "desc": "Rapidly absorbed fructose leading to metabolic syndrome."},
    "E951": {"name": "Aspartame", "risk": "Moderate", "desc": "Artificial sweetener categorized as possibly carcinogenic (WHO IARC Group 2B)."},
    "ASPARTAME": {"name": "Aspartame", "risk": "Moderate", "desc": "Artificial sweetener associated with altered gut microbiome and headaches."},
    "E955": {"name": "Sucralose", "risk": "Moderate", "desc": "Artificial sweetener that degrades gut microbiota biodiversity."},
    "SUCRALOSE": {"name": "Sucralose", "risk": "Moderate", "desc": "Chlorinated sweetener affecting insulin response and gut microflora."},
    "MALTODEXTRIN": {"name": "Maltodextrin", "risk": "High", "desc": "High glycemic index carbohydrate (GI 110-130), spiking blood sugar faster than table sugar."},
    "HYDROGENATED VEGETABLE OIL": {"name": "Trans Fat / Hydrogenated Oil", "risk": "Critical", "desc": "Contains harmful trans fatty acids that raise LDL cholesterol and damage arterial walls."},
    "PALM OIL": {"name": "Palm Oil / Palmolein", "risk": "Moderate", "desc": "High in saturated palmitic acid, associated with cardiovascular risk when consumed frequently."},
    "E171": {"name": "Titanium Dioxide", "risk": "Critical", "desc": "Nanoparticle whitening agent banned in EU due to DNA damage (genotoxicity)."},
    "E220": {"name": "Sulfur Dioxide", "risk": "High", "desc": "Preservative causing severe bronchospasm in asthmatics."},
    "E407": {"name": "Carrageenan", "risk": "High", "desc": "Thickener linked to gastrointestinal inflammation and ulcerative distress."}
}

DECEPTIVE_CLAIM_RULES = [
    {
        "claim": "No Added Sugar / Sugar-Free",
        "keywords": ["SUGAR FREE", "NO ADDED SUGAR", "ZERO SUGAR", "UNSWEETENED"],
        "hidden_culprits": ["MALTODEXTRIN", "HIGH FRUCTOSE CORN SYRUP", "AGAVE", "SUCRALOSE", "ASPARTAME", "DEXTROSE", "FRUCTOSE", "FRUIT JUICE CONCENTRATE"],
        "deception_msg": "Product claims to be Sugar-Free or No Added Sugar, but relies on high-glycemic substitutes like Maltodextrin/HFCS or artificial sweeteners that spike insulin."
    },
    {
        "claim": "Zero Trans Fat / Healthy Oils",
        "keywords": ["ZERO TRANS FAT", "TRANS FAT FREE", "HEART HEALTHY", "CHOLESTEROL FREE"],
        "hidden_culprits": ["HYDROGENATED", "PARTIALLY HYDROGENATED", "PALM OIL", "PALMOLEIN", "INTERESTERIFIED"],
        "deception_msg": "Claims Zero Trans Fat, but contains hydrogenated or refined palm oils which contain trace trans fats and high saturated fats."
    },
    {
        "claim": "100% Natural / Organic",
        "keywords": ["100% NATURAL", "ALL NATURAL", "ORGANIC", "PURE"],
        "hidden_culprits": ["E102", "E129", "E211", "E320", "E621", "SODIUM BENZOATE", "ARTIFICIAL FLAVOR", "ARTIFICIAL COLOR", "BHA", "MSG"],
        "deception_msg": "Marketed as '100% Natural', yet contains synthetic chemical additives, artificial colors, or chemical preservatives."
    },
    {
        "claim": "Multigrain / Whole Grain",
        "keywords": ["MULTIGRAIN", "WHOLE GRAIN", "WHEAT FIT", "FIBER RICH"],
        "hidden_culprits": ["REFINED WHEAT FLOUR", "MAIDA", "ENRICHED FLOUR", "BLEACHED WHEAT FLOUR"],
        "deception_msg": "Promoted as Multigrain/Whole Grain, but primary base ingredient is refined maida/white wheat flour with minimal whole grains."
    },
    {
        "claim": "Immunity / Fitness / Protein Bar",
        "keywords": ["PROTEIN RICH", "IMMUNITY BOOST", "FITNESS", "ENERGY BAR", "DIET"],
        "hidden_culprits": ["SUGAR", "GLUCOSE SYRUP", "INVERT SUGAR SYRUP", "PALM OIL", "MALTODEXTRIN"],
        "deception_msg": "Marketed as a fitness/protein snack, but sugar and syrup content exceeds actual protein nutrition."
    }
]

ALLERGEN_KEYWORD_MAP = {
    "Lactose": ["MILK", "MILK POWDER", "WHEY", "LACTOSE", "BUTTER", "CREAM", "CHEESE", "CASEIN", "MILK SOLIDS"],
    "Gluten": ["WHEAT", "REFINED WHEAT FLOUR", "MAIDA", "BARLEY", "RYE", "GLUTEN", "OATS (NON-CERTIFIED)", "ATTAR"],
    "Peanuts": ["PEANUT", "GROUNDNUT", "PEANUT OIL", "PEANUT FLOUR"],
    "Tree Nuts": ["ALMOND", "CASHEW", "WALNUT", "PISTACHIO", "HAZELNUT", "NUT"],
    "Soy": ["SOY", "SOYA", "SOYBEAN", "SOY LECITHIN", "SOY PROTEIN"],
    "Eggs": ["EGG", "EGG ALBUMEN", "EGG YOLK", "MAYONNAISE"],
    "Shellfish": ["SHRIMP", "CRAB", "LOBSTER", "PRAWN", "SHELLFISH", "FISH SAUCE"],
    "Sulfites": ["SULFITE", "SULPHITE", "SULFUR DIOXIDE", "E220", "SODIUM METABISULFITE"]
}

def extract_nutrition_facts(text):
    """
    Parses numerical nutrition facts from food label text using regex.
    Attempts to extract: Calories, Total Fat, Saturated Fat, Trans Fat, Carbohydrates,
    Total Sugars, Added Sugars, Protein, Dietary Fiber, Sodium, Salt, Serving Size, Servings Per Container.
    Only returns values that are actually present/readable; returns None for missing fields.
    """
    if not text:
        return {}

    text_upper = text.upper()
    
    # 1. Serving Size & Servings Per Container
    serving_size = None
    m_ss = re.search(r'(?:SERVING\s+SIZE|PER\s+SERVING)\s*:?\s*([0-9A-Za-z\s\(\)\.\/]+?)(?=\n|;|\.|SERVINGS|CALORIES|ENERGY|$)', text_upper)
    if m_ss:
        clean_ss = m_ss.group(1).strip()
        if len(clean_ss) < 30 and any(c.isdigit() for c in clean_ss):
            serving_size = clean_ss

    servings_per_container = None
    m_spc = re.search(r'(?:SERVINGS?\s+PER\s+(?:CONTAINER|PACKET|PACK|BOX))\s*:?\s*([0-9\.\s\~a-zA-Z]+?)(?=\n|;|\.|$)', text_upper)
    if m_spc:
        clean_spc = m_spc.group(1).strip()
        if len(clean_spc) < 20 and any(c.isdigit() for c in clean_spc):
            servings_per_container = clean_spc

    # 2. Calories / Energy
    calories = None
    m_cal = re.search(r'(?:CALORIES|ENERGY|KCAL)\s*:?\s*(\d+(?:\.\d+)?)', text_upper)
    if m_cal:
        try: calories = int(round(float(m_cal.group(1))))
        except: pass

    # 3. Total Fat
    total_fat_g = None
    m_tf = re.search(r'(?:TOTAL\s+)?FAT\s*:?\s*(\d+(?:\.\d+)?)\s*G', text_upper)
    if m_tf:
        try: total_fat_g = float(m_tf.group(1))
        except: pass

    # 4. Saturated Fat
    sat_fat_g = None
    m_sf = re.search(r'(?:SATURATED\s+FAT|SAT\s+FAT)\s*:?\s*(\d+(?:\.\d+)?)\s*G', text_upper)
    if m_sf:
        try: sat_fat_g = float(m_sf.group(1))
        except: pass

    # 5. Trans Fat
    trans_fat_g = None
    m_trf = re.search(r'(?:TRANS\s+FAT|TRANS-FAT)\s*:?\s*(\d+(?:\.\d+)?)\s*G', text_upper)
    if m_trf:
        try: trans_fat_g = float(m_trf.group(1))
        except: pass

    # 6. Carbohydrates
    carbs_g = None
    m_carb = re.search(r'(?:TOTAL\s+)?CARBOHYDRATES?|CARBS?\s*:?\s*(\d+(?:\.\d+)?)\s*G', text_upper)
    if m_carb:
        try: carbs_g = float(m_carb.group(1))
        except: pass

    # 7. Total Sugars & Added Sugars
    sugar_g = None
    m_sugar = re.search(r'(?:TOTAL\s+)?SUGARS?\s*:?\s*(\d+(?:\.\d+)?)\s*G', text_upper)
    if m_sugar:
        try: sugar_g = float(m_sugar.group(1))
        except: pass

    added_sugar_g = None
    m_adds = re.search(r'(?:ADDED\s+SUGARS?|INCLUDES\s+(\d+(?:\.\d+)?)\s*G\s+ADDED\s+SUGARS?)\s*:?\s*(\d+(?:\.\d+)?)?\s*G', text_upper)
    if m_adds:
        try:
            val_str = m_adds.group(1) or m_adds.group(2)
            if val_str:
                added_sugar_g = float(val_str)
        except: pass

    if sugar_g is None and added_sugar_g is not None:
        sugar_g = added_sugar_g

    # 8. Protein
    protein_g = None
    m_prot = re.search(r'PROTEIN\s*:?\s*(\d+(?:\.\d+)?)\s*G', text_upper)
    if m_prot:
        try: protein_g = float(m_prot.group(1))
        except: pass

    # 9. Dietary Fiber
    fiber_g = None
    m_fib = re.search(r'(?:DIETARY\s+)?FIBER\s*:?\s*(\d+(?:\.\d+)?)\s*G', text_upper)
    if m_fib:
        try: fiber_g = float(m_fib.group(1))
        except: pass

    # 10. Sodium & Salt
    sodium_mg = None
    salt_g = None
    m_sod = re.search(r'SODIUM\s*:?\s*(\d+(?:\.\d+)?)\s*(MG|G)', text_upper)
    if m_sod:
        try:
            val = float(m_sod.group(1))
            if m_sod.group(2) == 'G': val *= 1000
            sodium_mg = val
        except: pass

    m_salt = re.search(r'SALT\s*:?\s*(\d+(?:\.\d+)?)\s*(G|MG)', text_upper)
    if m_salt:
        try:
            s_val = float(m_salt.group(1))
            if m_salt.group(2) == 'MG':
                salt_g = round(s_val / 1000.0, 2)
            else:
                salt_g = s_val
            if sodium_mg is None:
                sodium_mg = round(salt_g * 400.0, 1)
        except: pass

    return {
        "serving_size": serving_size,
        "servings_per_container": servings_per_container,
        "calories": calories,
        "total_fat_g": total_fat_g,
        "sat_fat_g": sat_fat_g,
        "trans_fat_g": trans_fat_g,
        "carbs_g": carbs_g,
        "sugar_g": sugar_g,
        "added_sugar_g": added_sugar_g,
        "protein_g": protein_g,
        "fiber_g": fiber_g,
        "sodium_mg": sodium_mg,
        "salt_g": salt_g
    }

def calculate_normalized_nutrition_risk(nutr_facts):
    """
    Computes a normalized Nutritional Risk Score (0 - 100) from parsed facts using threshold comparisons.
    Returns (score, threshold_breakdown, nutrition_assessment_text).
    """
    if not nutr_facts:
        return None, {}, "Nutrition information could not be reliably extracted from this image."

    numeric_keys = ["calories", "total_fat_g", "sat_fat_g", "trans_fat_g", "carbs_g", "sugar_g", "added_sugar_g", "protein_g", "fiber_g", "sodium_mg"]
    has_any_num = any(nutr_facts.get(k) is not None for k in numeric_keys)

    if not has_any_num:
        return None, {}, "Nutrition information could not be reliably extracted from this image."

    components = []
    breakdown = {}
    high_concern_factors = []
    positive_factors = []

    # 1. Sugar (Thresholds: <=5g Low, 5g-20g Moderate, >20g High)
    if nutr_facts.get("sugar_g") is not None:
        sg = nutr_facts["sugar_g"]
        if sg <= 5.0:
            level = "Below Threshold (Low Contribution)"
            risk = (sg / 5.0) * 15.0
        elif sg <= 20.0:
            level = "Near Threshold (Moderate Contribution)"
            risk = 15.0 + ((sg - 5.0) / 15.0) * 40.0
            high_concern_factors.append(f"Sugar ({sg}g)")
        else:
            level = "Above Threshold (High Contribution)"
            risk = min(100.0, 55.0 + ((sg - 20.0) / 15.0) * 45.0)
            high_concern_factors.append(f"High Sugar ({sg}g)")
        components.append((risk, 1.2))
        breakdown["sugar"] = {"value": f"{sg}g", "level": level, "component_risk": round(risk, 1)}

    # Added Sugars
    if nutr_facts.get("added_sugar_g") is not None:
        asg = nutr_facts["added_sugar_g"]
        if asg > 5.0:
            high_concern_factors.append(f"Added Sugars ({asg}g)")

    # 2. Sodium (Thresholds: <=140mg Low, 140mg-600mg Moderate, >600mg High)
    if nutr_facts.get("sodium_mg") is not None:
        sd = nutr_facts["sodium_mg"]
        if sd <= 140.0:
            level = "Below Threshold (Low Contribution)"
            risk = (sd / 140.0) * 15.0
        elif sd <= 600.0:
            level = "Near Threshold (Moderate Contribution)"
            risk = 15.0 + ((sd - 140.0) / 460.0) * 40.0
            high_concern_factors.append(f"Sodium ({sd}mg)")
        else:
            level = "Above Threshold (High Contribution)"
            risk = min(100.0, 55.0 + ((sd - 600.0) / 400.0) * 45.0)
            high_concern_factors.append(f"High Sodium ({sd}mg)")
        components.append((risk, 1.0))
        breakdown["sodium"] = {"value": f"{sd}mg", "level": level, "component_risk": round(risk, 1)}

    # 3. Saturated Fat & Trans Fat
    if nutr_facts.get("sat_fat_g") is not None:
        sf = nutr_facts["sat_fat_g"]
        if sf <= 1.5:
            level = "Below Threshold (Low Contribution)"
            risk = (sf / 1.5) * 15.0
        elif sf <= 5.0:
            level = "Near Threshold (Moderate Contribution)"
            risk = 15.0 + ((sf - 1.5) / 3.5) * 40.0
            high_concern_factors.append(f"Saturated Fat ({sf}g)")
        else:
            level = "Above Threshold (High Contribution)"
            risk = min(100.0, 55.0 + ((sf - 5.0) / 5.0) * 45.0)
            high_concern_factors.append(f"High Saturated Fat ({sf}g)")
        components.append((risk, 1.1))
        breakdown["saturated_fat"] = {"value": f"{sf}g", "level": level, "component_risk": round(risk, 1)}

    if nutr_facts.get("trans_fat_g") is not None and nutr_facts["trans_fat_g"] > 0:
        tf_g = nutr_facts["trans_fat_g"]
        high_concern_factors.append(f"Trans Fat ({tf_g}g)")
        components.append((90.0, 1.5))

    # 4. Total Fat
    if nutr_facts.get("total_fat_g") is not None:
        tf = nutr_facts["total_fat_g"]
        if tf <= 3.0:
            level = "Below Threshold (Low Contribution)"
            risk = (tf / 3.0) * 10.0
        elif tf <= 15.0:
            level = "Near Threshold (Moderate Contribution)"
            risk = 10.0 + ((tf - 3.0) / 12.0) * 35.0
        else:
            level = "Above Threshold (High Contribution)"
            risk = min(80.0, 45.0 + ((tf - 15.0) / 15.0) * 35.0)
        components.append((risk, 0.8))
        breakdown["total_fat"] = {"value": f"{tf}g", "level": level, "component_risk": round(risk, 1)}

    # 5. Calories
    if nutr_facts.get("calories") is not None:
        cal = nutr_facts["calories"]
        if cal <= 120:
            level = "Below Threshold (Low Contribution)"
            risk = (cal / 120.0) * 10.0
        elif cal <= 350:
            level = "Near Threshold (Moderate Contribution)"
            risk = 10.0 + ((cal - 120.0) / 230.0) * 30.0
        else:
            level = "Above Threshold (High Contribution)"
            risk = min(80.0, 40.0 + ((cal - 350.0) / 250.0) * 40.0)
            high_concern_factors.append(f"Calories ({cal} kcal)")
        components.append((risk, 0.7))
        breakdown["calories"] = {"value": f"{cal} kcal", "level": level, "component_risk": round(risk, 1)}

    if not components:
        return None, {}, "Nutrition information could not be reliably extracted from this image."

    total_w = sum(c[1] for c in components)
    raw_nutr_risk = sum(c[0] * c[1] for c in components) / total_w

    # Beneficial Deductions (Protein & Fiber)
    prot_deduction = 0.0
    if nutr_facts.get("protein_g") is not None:
        p = nutr_facts["protein_g"]
        if p >= 4.0:
            prot_deduction = min(20.0, (p - 2.0) * 2.5)
            breakdown["protein_benefit"] = f"-{round(prot_deduction, 1)} pts"
            positive_factors.append(f"Protein ({p}g)")

    fib_deduction = 0.0
    if nutr_facts.get("fiber_g") is not None:
        f = nutr_facts["fiber_g"]
        if f >= 2.0:
            fib_deduction = min(15.0, f * 3.0)
            breakdown["fiber_benefit"] = f"-{round(fib_deduction, 1)} pts"
            positive_factors.append(f"Dietary Fiber ({f}g)")

    final_nutr_risk = max(0.0, min(100.0, raw_nutr_risk - prot_deduction - fib_deduction))

    # Construct Nutrition Assessment summary text
    if final_nutr_risk > 60:
        if high_concern_factors:
            assessment = f"Higher nutritional concern, mainly due to {', '.join(high_concern_factors)}."
        else:
            assessment = "Higher nutritional concern based on overall calorie and fat density."
    elif final_nutr_risk > 30:
        if high_concern_factors:
            assessment = f"Moderate nutritional concern, mainly due to {', '.join(high_concern_factors[:3])}."
        else:
            assessment = "Moderate nutritional concern based on balanced macro values."
    else:
        if positive_factors:
            assessment = f"Low nutritional concern, supported by beneficial {', '.join(positive_factors)}."
        else:
            assessment = "Low nutritional concern based on favorable extracted nutrition facts."

    return round(final_nutr_risk, 2), breakdown, assessment

def extract_ingredient_tokens(extracted_text):
    """
    Extracts individual ingredient names from label text.
    """
    if not extracted_text:
        return []
    
    m = re.search(r'INGREDIENTS?\s*:?\s*(.*?)(?=\.|\n\n|CONTAINS:|ALLERGENS:|NUTRITION|DISTRIBUTED|MANUFACTURED|$)', extracted_text, re.IGNORECASE | re.DOTALL)
    if m:
        ing_text = m.group(1).strip()
    else:
        m_nut = re.search(r'(.*?)(?=NUTRITION|FACTS|SERVING|$)', extracted_text, re.IGNORECASE | re.DOTALL)
        ing_text = m_nut.group(1).strip() if m_nut else extracted_text.strip()

    raw_tokens = re.split(r'[,;\n•\*\.]| AND ', ing_text)
    tokens = []
    seen = set()
    for tok in raw_tokens:
        clean = re.sub(r'[\(\)\[\]\d+%:]', ' ', tok).strip()
        clean_upper = clean.upper()
        if len(clean) >= 3 and clean_upper not in seen:
            if not any(k in clean_upper for k in ['NUTRITION', 'SERVING', 'CALORIES', 'SODIUM', 'CARBOHYDRATE', 'PROTEIN', 'TOTAL FAT', 'SATURATED FAT']):
                seen.add(clean_upper)
                tokens.append(clean)
    return tokens

def extract_detected_ingredients(extracted_text):
    """
    Extracts individual ingredient names cleanly from label text for transparency display.
    Does NOT attach individual risk levels (High/Moderate/Low) to ingredients.
    """
    if not extracted_text or "Could not extract" in extracted_text:
        return []

    m = re.search(r'INGREDIENTS?\s*:?\s*(.*?)(?=\.|\n\n|CONTAINS:|ALLERGENS:|NUTRITION|DISTRIBUTED|MANUFACTURED|$)', extracted_text, re.IGNORECASE | re.DOTALL)
    if m:
        ing_text = m.group(1).strip()
    else:
        m_nut = re.search(r'(.*?)(?=NUTRITION|FACTS|SERVING|$)', extracted_text, re.IGNORECASE | re.DOTALL)
        ing_text = m_nut.group(1).strip() if m_nut else extracted_text.strip()

    raw_tokens = re.split(r'[,;\n•\*\.]| AND ', ing_text)
    ingredients_list = []
    seen = set()

    for tok in raw_tokens:
        clean = re.sub(r'\b\d+(?:\.\d+)?\s*(?:G|MG|KCAL|%|OZ|ML|L)?\b', '', tok, flags=re.IGNORECASE)
        clean = re.sub(r'[\(\)\[\]\d+%:]', ' ', clean).strip()
        clean = re.sub(r'\s+', ' ', clean)
        clean_upper = clean.upper()
        if len(clean) >= 2 and clean_upper not in seen:
            if not any(k in clean_upper for k in ['NUTRITION', 'SERVING', 'CALORIES', 'SODIUM', 'CARBOHYDRATE', 'PROTEIN', 'TOTAL FAT', 'SATURATED FAT', 'INGREDIENTS']):
                seen.add(clean_upper)
                ingredients_list.append(clean.title())

    return ingredients_list

def run_winrt_ocr(image_path):
    """
    Windows Native OCR Engine (winrt.windows.media.ocr):
    Natively reads JPG, PNG, WEBP, HEIC, JPEG, screenshots, and device photos on Windows 10/11
    without requiring external executable installations.
    """
    try:
        import asyncio
        import winrt.windows.media.ocr as ocr
        import winrt.windows.graphics.imaging as imaging
        import winrt.windows.storage as storage

        async def _ocr():
            abs_path = os.path.abspath(image_path)
            if not os.path.exists(abs_path):
                return ""
            file = await storage.StorageFile.get_file_from_path_async(abs_path)
            stream = await file.open_async(storage.FileAccessMode.READ)
            decoder = await imaging.BitmapDecoder.create_async(stream)
            software_bitmap = await decoder.get_software_bitmap_async()
            engine = ocr.OcrEngine.try_create_from_user_profile_languages()
            if not engine:
                engine = ocr.OcrEngine.try_create_from_language(ocr.Language("en-US"))
            if not engine:
                return ""
            result = await engine.recognize_async(software_bitmap)
            return result.text or ""

        try:
            return asyncio.run(_ocr())
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            res = loop.run_until_complete(_ocr())
            loop.close()
            return res
    except Exception as e:
        print(f"[WinRT OCR Notice] {e}")
        return ""

def extract_text_from_image(image_path, product_name=""):
    """
    ROBUST MULTI-ENGINE OCR EXTRACTION PIPELINE:
    - Pass 1: Windows Native OCR (winrt.windows.media.ocr) - High speed, ultra-accurate for device images, JPG/PNG/WEBP/HEIC/screenshots.
    - Pass 2: Pytesseract OCR (Tesseract Executable if available).
    - Pass 3: PIL & OpenCV Preprocessing (Upscaling, Grayscale, Contrast Amplification, Binarization, Sharpening).
    Returns extracted text string. Only returns unreadable notice if ALL passes fail completely (<5 chars).
    """
    extracted = ""
    
    # Pass 1: Windows Native OCR Engine
    winrt_text = run_winrt_ocr(image_path)
    if winrt_text and len(winrt_text.strip()) >= 5:
        extracted = winrt_text.strip()
        print(f"[OCR Pipeline] WinRT Native OCR succeeded for '{product_name}': {len(extracted)} chars extracted.")

    # Pass 2 & 3: Pytesseract OCR with PIL/OpenCV Preprocessing (as fallback or enhancement)
    try:
        from PIL import Image, ImageEnhance, ImageFilter
        import pytesseract

        tesseract_paths = [
            r'C:\Program Files\Tesseract-OCR\tesseract.exe',
            r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
            os.path.expanduser(r'~\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'),
            r'C:\Tesseract-OCR\tesseract.exe'
        ]
        for p in tesseract_paths:
            if os.path.exists(p):
                pytesseract.pytesseract.tesseract_cmd = p
                break

        img = Image.open(image_path)
        if img.mode != 'RGB':
            img = img.convert('RGB')

        tess_text1 = pytesseract.image_to_string(img)
        
        # Preprocessing Pass: Upscaled + Contrast
        w, h = img.size
        upscaled = img.resize((int(w * 1.5), int(h * 1.5)), Image.Resampling.LANCZOS)
        gray = upscaled.convert('L')
        enhancer = ImageEnhance.Contrast(gray)
        enhanced_img = enhancer.enhance(2.0)
        tess_text2 = pytesseract.image_to_string(enhanced_img)

        # Merge richest pytesseract output if WinRT was empty
        best_tess = tess_text1 if len(tess_text1) > len(tess_text2) else tess_text2
        if not extracted and len(best_tess.strip()) >= 5:
            extracted = best_tess.strip()
            print(f"[OCR Pipeline] Pytesseract OCR succeeded for '{product_name}': {len(extracted)} chars extracted.")
        elif extracted and len(best_tess.strip()) >= 15 and not any(k in extracted.upper() for k in ["INGREDIENT", "NUTRITION", "FACTS"]):
            # Merge if Pytesseract found headings missing in WinRT
            extracted += "\n" + best_tess.strip()
    except Exception as e:
        print(f"[OCR Pipeline Notice] Pytesseract notice: {e}")

    # Explicit unreadable notice ONLY if all OCR passes returned empty/unreadable text
    if not extracted or len(extracted.strip()) < 5:
        extracted = "Could not extract the ingredient list from this image. Please upload a clearer food-label image."

    print("====================================")
    print(f"FINAL OCR EXTRACTED TEXT FOR '{product_name}' ({os.path.basename(image_path)}):")
    print(extracted[:300])
    print("====================================")

    return extracted

def analyze_food_label(extracted_text, user_profile=None, product_name="Scanned Food Product"):
    """
    MULTI-FACTOR DYNAMIC FOOD LABEL HEALTH ANALYSIS ENGINE
    - Extracts nutrition facts and calculates normalized nutrition risk.
    - Extracts ingredient composition and matches against risk reference dataset.
    - Performs deception detection.
    - Computes ONE overall Health Score (0-100 scale):
        - Below 30: Good / Lower Concern (Green)
        - 30-60: Moderate (Orange)
        - Above 60: Higher Concern / Not Recommended (Red)
    - Generates personalized suggestions according to user profile.
    - DOES NOT display individual ingredient risk labels.
    """
    empty_nutr = {
        "serving_size": None, "servings_per_container": None, "calories": None,
        "total_fat_g": None, "sat_fat_g": None, "trans_fat_g": None, "carbs_g": None,
        "sugar_g": None, "added_sugar_g": None, "protein_g": None, "fiber_g": None,
        "sodium_mg": None, "salt_g": None
    }

    # Handle unreadable text gracefully
    if not extracted_text or "Could not extract" in extracted_text or len(extracted_text.strip()) < 5:
        return {
            "product_name": product_name,
            "extracted_text": "Could not extract the ingredient list from this image. Please upload a clearer food-label image.",
            "health_score": 0,
            "risk_category": "Unreadable",
            "status_label": "⚠️ UNREADABLE LABEL",
            "recommendation_text": "UPLOAD CLEARER IMAGE",
            "recommendation_label": "⚠️ UNREADABLE / UPLOAD CLEARER IMAGE",
            "short_explanation": "Nutrition and ingredient information could not be reliably extracted from this image.",
            "deceptive_claims_status": "Unable to verify this claim from the available label information.",
            "deceptive_claims": [],
            "detected_ingredients": [],
            "extracted_nutrition": empty_nutr,
            "nutrition_assessment": "Nutrition information could not be reliably extracted from this image.",
            "key_factors": ["Label text was unreadable or incomplete."],
            "personalized_suggestions": ["Please upload a clearer image of the food product's ingredient and nutrition label."],
            "detected_additives": [],
            "detected_allergens": [],
            "recommendations": ["⚠️ Please upload a clearer image of the food product label."]
        }

    text_upper = extracted_text.upper()

    # 1. Parse Additives
    detected_additives = []
    try:
        conn = get_db_connection()
        db_additives = conn.execute("SELECT * FROM additives_db").fetchall()
        conn.close()
        db_map = {item['code_name'].upper(): item for item in db_additives}
        db_map.update({item['common_name'].upper(): item for item in db_additives})
    except:
        db_map = {}

    for code, info in ADDITIVES_DICT.items():
        if code in text_upper:
            db_entry = db_map.get(code)
            detected_additives.append({
                "code": code,
                "name": info["name"],
                "risk": info["risk"],
                "desc": info["desc"],
                "fda_status": db_entry["fda_status"] if db_entry else "Approved with limits",
                "efsa_status": db_entry["efsa_status"] if db_entry else "Monitored"
            })

    seen_codes = set()
    unique_additives = []
    for item in detected_additives:
        if item["code"] not in seen_codes:
            seen_codes.add(item["code"])
            unique_additives.append(item)

    # 2. Deception Detection
    deceptive_claims = []
    for rule in DECEPTIVE_CLAIM_RULES:
        found_claim_kw = [kw for kw in rule["keywords"] if kw in text_upper]
        found_culprits = [culprit for culprit in rule["hidden_culprits"] if culprit in text_upper]
        if found_claim_kw and found_culprits:
            deceptive_claims.append({
                "claim_name": rule["claim"],
                "matched_kw": ", ".join(found_claim_kw),
                "culprits_found": ", ".join(found_culprits),
                "explanation": rule["deception_msg"]
            })

    if deceptive_claims:
        deceptive_claims_status = "Potentially Misleading Claim Detected"
    else:
        deceptive_claims_status = "No significant misleading claim detected."

    # 3. Extract Nutrition Facts & Calculate Nutrition Risk
    nutrition_facts = extract_nutrition_facts(extracted_text)
    nutr_risk_score, nutr_breakdown, nutrition_assessment = calculate_normalized_nutrition_risk(nutrition_facts)

    # 4. Extract Detected Ingredients List (For Transparency Display - NO Individual Risk Labels!)
    detected_ingredients = extract_detected_ingredients(extracted_text)

    # Internal composition evaluation for overall score (without showing per-ingredient badges)
    comp_risk_score = 15.0 # baseline neutral score
    concerning_items = []
    
    if any(k in text_upper for k in ["HYDROGENATED", "TRANS FAT", "TITANIUM DIOXIDE", "SODIUM NITRITE"]):
        comp_risk_score += 40.0
        concerning_items.append("strongly flagged/hydrogenated additives")

    if any(k in text_upper for k in ["HIGH FRUCTOSE CORN SYRUP", "HFCS", "BHA", "BHT", "SODIUM BENZOATE", "TARTRAZINE", "RED 40"]):
        comp_risk_score += 25.0
        concerning_items.append("high-risk chemical additives or HFCS")

    if any(k in text_upper for k in ["PALM OIL", "PALMOLEIN", "REFINED WHEAT FLOUR", "MAIDA", "MONOSODIUM GLUTAMATE", "MSG", "ASPARTAME", "SUCRALOSE", "MALTODEXTRIN"]):
        comp_risk_score += 15.0
        concerning_items.append("refined ingredients or artificial sweeteners")

    if len(unique_additives) >= 3:
        comp_risk_score += 15.0
    elif len(unique_additives) >= 1:
        comp_risk_score += 8.0

    comp_risk_score = min(100.0, comp_risk_score)

    # 5. Multi-Factor Score Combination
    deception_penalty = 15.0 if deceptive_claims else 0.0

    if nutr_risk_score is not None:
        raw_final_score = (0.55 * nutr_risk_score) + (0.35 * comp_risk_score) + (0.10 * deception_penalty)
    else:
        raw_final_score = (0.85 * comp_risk_score) + (0.15 * deception_penalty)

    final_score = int(round(raw_final_score))
    final_score = max(0, min(100, final_score))

    # Thresholds: Below 30 Good, 30-60 Moderate, Above 60 High Concern
    if final_score <= 30:
        risk_category = "Good"
        status_label = "🟢 GOOD / LOWER CONCERN"
        recommendation_text = "GOOD CHOICE"
        recommendation_label = "🟢 GOOD CHOICE"
    elif final_score <= 60:
        risk_category = "Moderate"
        status_label = "🟠 MODERATE CONCERN"
        recommendation_text = "CONSUME WITH CAUTION"
        recommendation_label = "🟠 CONSUME WITH CAUTION"
    else:
        risk_category = "Higher Concern"
        status_label = "🔴 HIGHER CONCERN"
        recommendation_text = "NOT A GOOD CHOICE"
        recommendation_label = "🔴 NOT A GOOD CHOICE"

    # 6. Key Factors Generation
    key_factors = []
    if nutrition_facts.get("sugar_g") is not None and nutrition_facts["sugar_g"] > 15:
        key_factors.append(f"High sugar content ({nutrition_facts['sugar_g']}g per serving)")
    if nutrition_facts.get("added_sugar_g") is not None and nutrition_facts["added_sugar_g"] > 8:
        key_factors.append(f"Significant added sugars ({nutrition_facts['added_sugar_g']}g)")
    if nutrition_facts.get("sodium_mg") is not None and nutrition_facts["sodium_mg"] > 400:
        key_factors.append(f"Elevated sodium level ({nutrition_facts['sodium_mg']}mg)")
    if nutrition_facts.get("sat_fat_g") is not None and nutrition_facts["sat_fat_g"] > 4:
        key_factors.append(f"Higher saturated fat content ({nutrition_facts['sat_fat_g']}g)")
    if nutrition_facts.get("trans_fat_g") is not None and nutrition_facts["trans_fat_g"] > 0:
        key_factors.append(f"Presence of Trans Fat ({nutrition_facts['trans_fat_g']}g)")
    if deceptive_claims:
        key_factors.append("Potentially misleading label claim(s) detected")
    if unique_additives:
        key_factors.append(f"Contains {len(unique_additives)} chemical additive(s)/E-numbers")
    if nutrition_facts.get("fiber_g") is not None and nutrition_facts["fiber_g"] >= 3:
        key_factors.append(f"Beneficial dietary fiber content ({nutrition_facts['fiber_g']}g)")
    if nutrition_facts.get("protein_g") is not None and nutrition_facts["protein_g"] >= 6:
        key_factors.append(f"Good protein content ({nutrition_facts['protein_g']}g)")

    if not key_factors:
        if final_score <= 30:
            key_factors.append("Product consists predominantly of low-risk ingredients with low nutritional concern.")
        elif final_score <= 60:
            key_factors.append("Moderate overall score driven by balanced ingredients and processing level.")
        else:
            key_factors.append("Overall score reflects elevated ingredient processing and nutritional concern.")

    # 7. Short Explanation
    if final_score <= 30:
        short_explanation = f"Overall Product Health Score: {final_score}/100 — Good / Lower Concern. The product has relatively lower overall health concerns based on extracted nutrition and ingredient data."
    elif final_score <= 60:
        short_explanation = f"Overall Product Health Score: {final_score}/100 — Moderate Concern. The product has some nutritional or ingredient-related concerns. Consider consuming in moderation."
    else:
        short_explanation = f"Overall Product Health Score: {final_score}/100 — Higher Concern. The product has relatively higher overall health concerns due to elevated nutritional or ingredient risk factors."

    # 8. User Profile Personalized Health Suggestions
    user_med = []
    user_allergies = []
    diet_type = "Standard Omnivore"

    if user_profile:
        if user_profile.get("medical_conditions"):
            if isinstance(user_profile["medical_conditions"], str):
                user_med = [c.strip() for c in user_profile["medical_conditions"].split(",") if c.strip()]
            elif isinstance(user_profile["medical_conditions"], list):
                user_med = user_profile["medical_conditions"]
        if user_profile.get("allergies"):
            if isinstance(user_profile["allergies"], str):
                user_allergies = [a.strip() for a in user_profile["allergies"].split(",") if a.strip()]
            elif isinstance(user_profile["allergies"], list):
                user_allergies = user_profile["allergies"]
        if user_profile.get("diet_type"):
            diet_type = user_profile["diet_type"]

    personalized_suggestions = []

    # Allergy checks
    detected_allergens = []
    for allergy in user_allergies:
        keywords = ALLERGEN_KEYWORD_MAP.get(allergy, [allergy.upper()])
        matches = [kw for kw in keywords if kw in text_upper]
        if matches:
            detected_allergens.append({"allergy": allergy, "matched_ingredients": ", ".join(matches)})
            personalized_suggestions.append(f"⚠️ **ALLERGY ALERT**: Contains ingredients ({', '.join(matches)}) matching your selected **{allergy}** allergy.")

    # Medical profile checks
    sugar_val = nutrition_facts.get("sugar_g")
    sodium_val = nutrition_facts.get("sodium_mg")
    sat_val = nutrition_facts.get("sat_fat_g")
    cal_val = nutrition_facts.get("calories")
    carb_val = nutrition_facts.get("carbs_g")

    if any(m in user_med for m in ["Diabetes", "Pre-Diabetes"]):
        if (sugar_val is not None and sugar_val > 5) or (carb_val is not None and carb_val > 20) or any(k in text_upper for k in ["SUGAR", "MALTODEXTRIN", "HFCS", "GLUCOSE"]):
            s_detail = f" ({sugar_val}g sugar)" if sugar_val is not None else ""
            personalized_suggestions.append(f"🩸 **Blood Sugar / Diabetes Warning**: This product may not be suitable for your selected blood-sugar-conscious profile because of its sugar/carbohydrate content{s_detail} and refined sweeteners.")
        else:
            personalized_suggestions.append("🩸 **Blood Sugar / Diabetes Profile**: Low sugar content detected; aligns well with your blood-sugar-conscious profile.")

    if any(m in user_med for m in ["Hypertension", "Blood Pressure"]):
        if (sodium_val is not None and sodium_val > 140) or any(k in text_upper for k in ["SODIUM", "SALT"]):
            s_detail = f" ({sodium_val}mg sodium)" if sodium_val is not None else ""
            personalized_suggestions.append(f"🫀 **Blood Pressure Warning**: Consider limiting this product because its sodium level{s_detail} is relatively high for your blood pressure management goals.")
        else:
            personalized_suggestions.append("🫀 **Blood Pressure Profile**: Low sodium content detected; suitable for your blood-pressure-conscious profile.")

    if any(m in user_med for m in ["Heart Condition", "High Cholesterol"]):
        if (sat_val is not None and sat_val > 1.5) or any(k in text_upper for k in ["PALM OIL", "HYDROGENATED", "TRANS FAT"]):
            sf_detail = f" ({sat_val}g saturated fat)" if sat_val is not None else ""
            personalized_suggestions.append(f"❤️ **Heart Health Caution**: This product contains elevated saturated fat{sf_detail} or refined oils, requiring caution for your cardiovascular profile.")
        else:
            personalized_suggestions.append("❤️ **Heart Health Profile**: Low saturated fat and clean lipids support your cardiovascular health profile.")

    if "Keto / Low-Carb" in diet_type:
        if (carb_val is not None and carb_val > 10) or (sugar_val is not None and sugar_val > 3):
            personalized_suggestions.append(f"🥑 **Keto / Low-Carb Alert**: Carbohydrate content ({carb_val if carb_val is not None else sugar_val}g) exceeds low-carb / keto diet thresholds.")
        else:
            personalized_suggestions.append("🥑 **Keto / Low-Carb Profile**: Carbohydrate count is within low-carb bounds.")

    if not personalized_suggestions:
        if final_score <= 30:
            personalized_suggestions.append("🌿 **General Health Suggestion**: Excellent choice! This product aligns well with a standard healthy eating pattern.")
        elif final_score <= 60:
            personalized_suggestions.append("⚖️ **General Health Suggestion**: Enjoy in moderation as part of a balanced diet.")
        else:
            personalized_suggestions.append("⚠️ **General Health Suggestion**: Consider replacing this item with a less processed alternative.")

    return {
        "product_name": product_name,
        "extracted_text": extracted_text,
        "health_score": final_score,
        "risk_category": risk_category,
        "status_label": status_label,
        "recommendation_text": recommendation_text,
        "recommendation_label": recommendation_label,
        "short_explanation": short_explanation,
        "deceptive_claims_status": deceptive_claims_status,
        "deceptive_claims": deceptive_claims,
        "detected_ingredients": detected_ingredients,
        "extracted_nutrition": nutrition_facts,
        "nutrition_assessment": nutrition_assessment,
        "key_factors": key_factors,
        "personalized_suggestions": personalized_suggestions,
        "detected_additives": unique_additives,
        "detected_allergens": detected_allergens,
        "recommendations": personalized_suggestions
    }





