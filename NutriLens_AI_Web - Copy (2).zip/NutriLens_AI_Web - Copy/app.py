import os
import json
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from database import init_db, get_db_connection
from analysis_engine import extract_text_from_image, analyze_food_label

app = Flask(__name__)
app.secret_key = 'nutrilens_ai_super_secret_key_2026'

# Configure Upload Folder & File Restrictions (32MB Max for high-res camera photos)
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024  # 32 MB max upload limit

ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp', 'heic', 'heif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Initialize DB on Startup
init_db()

@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE LOWER(email) = LOWER(?)", (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            session["is_admin"] = bool(user["is_admin"])

            # Ensure health profile exists for regular user
            conn = get_db_connection()
            profile = conn.execute("SELECT * FROM health_profiles WHERE user_id = ?", (user["id"],)).fetchone()
            if not profile and not user["is_admin"]:
                conn.execute('''
                    INSERT OR IGNORE INTO health_profiles (user_id, age, gender, diet_type, medical_conditions, allergies)
                    VALUES (?, 28, 'Standard', 'Standard Omnivore', '', '')
                ''', (user["id"],))
                conn.commit()
                profile = conn.execute("SELECT * FROM health_profiles WHERE user_id = ?", (user["id"],)).fetchone()
            conn.close()

            flash(f"Welcome back, {user['name']}!", "success")
            
            if user["is_admin"]:
                return redirect(url_for("admin_page"))
            
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid email or password", "danger")

    return render_template("login.html")

@app.route("/signup", methods=["GET", "POST"])
@app.route("/register", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""

        if not name or not email or not password:
            flash("Please fill in all fields.", "danger")
            return render_template("signup.html")

        hashed_pw = generate_password_hash(password)

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", (name, email, hashed_pw))
            user_id = cursor.lastrowid
            
            # Automatically initialize default health profile for new user
            cursor.execute('''
                INSERT INTO health_profiles (user_id, age, gender, diet_type, medical_conditions, allergies)
                VALUES (?, 28, 'Standard', 'Standard Omnivore', '', '')
            ''', (user_id,))
            
            conn.commit()
            conn.close()
            flash("Registration successful! Please login to continue.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            conn.close()
            flash("Email already registered! Please login or use a different email.", "danger")

    return render_template("signup.html")

@app.route("/register_alias", methods=["GET", "POST"])
def register():
    return signup()

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))

@app.route("/profile-setup", methods=["GET", "POST"])
@app.route("/personal-details", methods=["GET", "POST"])
def profile_setup():
    if not session.get("user_id"):
        return redirect(url_for("login"))

    user_id = session.get("user_id")

    if request.method == "POST":
        age = request.form.get("age") or 28
        gender = request.form.get("gender") or "Standard"
        allergies = request.form.getlist("allergies")
        medical_conditions = request.form.getlist("medical_conditions")
        diet_type = request.form.get("diet_type") or "Standard Omnivore"

        allergies_str = ", ".join(allergies)
        medical_str = ", ".join(medical_conditions)

        conn = get_db_connection()
        conn.execute('''
            INSERT INTO health_profiles (user_id, age, gender, diet_type, allergies, medical_conditions)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                age = excluded.age,
                gender = excluded.gender,
                diet_type = excluded.diet_type,
                allergies = excluded.allergies,
                medical_conditions = excluded.medical_conditions,
                updated_at = CURRENT_TIMESTAMP
        ''', (user_id, age, gender, diet_type, allergies_str, medical_str))
        conn.commit()
        conn.close()

        flash("Health profile saved successfully!", "success")
        return redirect(url_for("dashboard"))

    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    profile = conn.execute("SELECT * FROM health_profiles WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()

    return render_template("profile.html", user=user, profile=profile)

@app.route("/personal_details", methods=["GET", "POST"])
def personal_details():
    return profile_setup()


@app.route("/dashboard")
def dashboard():
    if not session.get("user_id"):
        return redirect(url_for("login"))

    user_id = session.get("user_id")
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    scans = conn.execute("SELECT * FROM scans WHERE user_id = ? ORDER BY scanned_at DESC", (user_id,)).fetchall()
    profile = conn.execute("SELECT * FROM health_profiles WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()

    total_scans = len(scans)
    safe_scans = sum(1 for s in scans if s["risk_category"] == "Safe" or (s["health_score"] is not None and s["health_score"] <= 30))
    moderate_scans = sum(1 for s in scans if s["risk_category"] == "Moderate" or (s["health_score"] is not None and 30 < s["health_score"] <= 60))
    flagged_scans = sum(1 for s in scans if s["risk_category"] in ["Red Flag", "High Concern"] or (s["health_score"] is not None and s["health_score"] > 60))

    stats = {
        "total": total_scans,
        "safe": safe_scans,
        "moderate": moderate_scans,
        "redflag": flagged_scans
    }

    return render_template("home.html", user=user, stats=stats, recent_scans=scans, profile=profile, scans=scans, total_scans=total_scans, safe_scans=safe_scans, moderate_scans=moderate_scans, flagged_scans=flagged_scans)


@app.route("/upload")
def upload_page():
    if not session.get("user_id"):
        return redirect(url_for("login"))
    return render_template("upload.html")

@app.route("/analyze", methods=["POST"])
def analyze_upload():
    if not session.get("user_id"):
        return redirect(url_for("login"))

    user_id = session.get("user_id")
    product_name = request.form.get("product_name") or "Scanned Packaged Food"
    manual_text = request.form.get("manual_text") or ""
    image_file = request.files.get("label_image")

    extracted_text = ""
    filename = ""

    if image_file and image_file.filename != '':
        filename = secure_filename(image_file.filename)
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        image_file.save(save_path)
        extracted_text = extract_text_from_image(save_path, product_name=product_name)
    
    if manual_text.strip():
        extracted_text = manual_text.strip() if not extracted_text else (extracted_text + "\n" + manual_text.strip())

    # Fetch User Health Profile
    conn = get_db_connection()
    profile = conn.execute("SELECT * FROM health_profiles WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()

    user_profile_dict = {}
    if profile:
        user_profile_dict = {
            "allergies": profile["allergies"],
            "medical_conditions": profile["medical_conditions"],
            "diet_type": profile["diet_type"]
        }

    # Run AI Analysis Engine
    analysis_res = analyze_food_label(extracted_text, user_profile=user_profile_dict, product_name=product_name)

    # Save to Database
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO scans (user_id, product_name, image_filename, extracted_text, health_score, risk_category, deceptive_claims, detected_additives, detected_allergens, recommendations)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        user_id,
        product_name,
        filename,
        extracted_text,
        analysis_res["health_score"],
        analysis_res["risk_category"],
        json.dumps(analysis_res["deceptive_claims"]),
        json.dumps(analysis_res["detected_additives"]),
        json.dumps(analysis_res["detected_allergens"]),
        json.dumps(analysis_res["recommendations"])
    ))
    conn.commit()
    scan_id = cursor.lastrowid
    conn.close()

    flash("Food label successfully scanned and analyzed!", "success")
    return redirect(url_for("view_result", scan_id=scan_id))

@app.route("/result/<int:scan_id>")
def view_result(scan_id):
    if not session.get("user_id"):
        return redirect(url_for("login"))

    user_id = session.get("user_id")
    conn = get_db_connection()
    scan = conn.execute("SELECT * FROM scans WHERE id = ? AND user_id = ?", (scan_id, user_id)).fetchone()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    profile = conn.execute("SELECT * FROM health_profiles WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()

    if not scan:
        flash("Scan record not found.", "danger")
        return redirect(url_for("dashboard"))

    user_profile_dict = {}
    if profile:
        user_profile_dict = {
            "allergies": profile["allergies"],
            "medical_conditions": profile["medical_conditions"],
            "diet_type": profile["diet_type"]
        }

    # Re-run analysis engine to ensure full structured output (nutrition facts, key factors, deception status, personalized suggestions)
    analysis_res = analyze_food_label(scan["extracted_text"], user_profile=user_profile_dict, product_name=scan["product_name"])

    result_data = {
        "product_name": scan["product_name"],
        "extracted_text": scan["extracted_text"],
        "image_filename": scan["image_filename"],
        "health_score": scan["health_score"] if scan["health_score"] is not None else analysis_res["health_score"],
        "risk_category": analysis_res["risk_category"],
        "status_label": analysis_res["status_label"],
        "recommendation_text": analysis_res["recommendation_text"],
        "recommendation_label": analysis_res["recommendation_label"],
        "short_explanation": analysis_res["short_explanation"],
        "deceptive_claims_status": analysis_res["deceptive_claims_status"],
        "deceptive_claims": analysis_res["deceptive_claims"],
        "detected_ingredients": analysis_res["detected_ingredients"],
        "extracted_nutrition": analysis_res["extracted_nutrition"],
        "nutrition_assessment": analysis_res["nutrition_assessment"],
        "key_factors": analysis_res["key_factors"],
        "personalized_suggestions": analysis_res["personalized_suggestions"],
        "detected_additives": analysis_res["detected_additives"],
        "detected_allergens": analysis_res["detected_allergens"]
    }

    return render_template("result.html", result=result_data, user=user, profile=profile)

@app.route("/history")
def history_page():
    if not session.get("user_id"):
        return redirect(url_for("login"))

    user_id = session.get("user_id")
    conn = get_db_connection()
    scans = conn.execute("SELECT * FROM scans WHERE user_id = ? ORDER BY scanned_at DESC", (user_id,)).fetchall()
    conn.close()

    return render_template("history.html", scans=scans)

@app.route("/profile", methods=["GET", "POST"])
def profile_page():
    if not session.get("user_id"):
        return redirect(url_for("login"))

    user_id = session.get("user_id")

    if request.method == "POST":
        age = request.form.get("age")
        gender = request.form.get("gender")
        diet_type = request.form.get("diet_type")
        allergies = ",".join(request.form.getlist("allergies"))
        medical_conditions = ",".join(request.form.getlist("medical_conditions"))

        conn = get_db_connection()
        conn.execute('''
            UPDATE health_profiles 
            SET age = ?, gender = ?, diet_type = ?, allergies = ?, medical_conditions = ?
            WHERE user_id = ?
        ''', (age, gender, diet_type, allergies, medical_conditions, user_id))
        conn.commit()
        conn.close()

        flash("Health profile updated successfully!", "success")
        return redirect(url_for("profile_page"))

    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    profile = conn.execute("SELECT * FROM health_profiles WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()

    return render_template("profile.html", user=user, profile=profile)

@app.route("/admin")
def admin_page():
    if not session.get("user_id") or not session.get("is_admin"):
        flash("Admin access restricted.", "danger")
        return redirect(url_for("dashboard"))

    conn = get_db_connection()
    total_users = conn.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
    total_scans = conn.execute("SELECT COUNT(*) as c FROM scans").fetchone()["c"]
    redflag_scans = conn.execute("SELECT COUNT(*) as c FROM scans WHERE risk_category = 'Red Flag'").fetchone()["c"]
    total_additives = conn.execute("SELECT COUNT(*) as c FROM additives_db").fetchone()["c"]

    additives = conn.execute("SELECT * FROM additives_db ORDER BY id DESC").fetchall()
    users_list = conn.execute('''
        SELECT users.id, users.name, users.email, users.is_admin, users.created_at, COUNT(scans.id) as scan_count
        FROM users LEFT JOIN scans ON users.id = scans.user_id
        GROUP BY users.id
        ORDER BY users.id DESC
    ''').fetchall()
    global_scans = conn.execute('''
        SELECT scans.*, users.name as user_name 
        FROM scans JOIN users ON scans.user_id = users.id 
        ORDER BY scans.scanned_at DESC LIMIT 10
    ''').fetchall()
    conn.close()

    admin_stats = {
        "total_users": total_users,
        "total_scans": total_scans,
        "redflag_scans": redflag_scans,
        "total_additives": total_additives
    }

    return render_template("admin.html", admin_stats=admin_stats, additives=additives, users_list=users_list, global_scans=global_scans)

@app.route("/admin/add-additive", methods=["POST"])
def add_additive():
    if not session.get("user_id") or not session.get("is_admin"):
        flash("Unauthorized action.", "danger")
        return redirect(url_for("dashboard"))

    code_name = request.form.get("code_name").strip().upper()
    common_name = request.form.get("common_name").strip()
    category = request.form.get("category")
    risk_level = request.form.get("risk_level")
    health_risks = request.form.get("health_risks").strip()

    conn = get_db_connection()
    try:
        conn.execute('''
            INSERT INTO additives_db (code_name, common_name, category, risk_level, health_risks, fda_status, efsa_status)
            VALUES (?, ?, ?, ?, ?, 'Approved', 'Monitored')
        ''', (code_name, common_name, category, risk_level, health_risks))
        conn.commit()
        flash(f"Additive {code_name} added to database successfully!", "success")
    except Exception as e:
        flash(f"Error adding additive: {e}", "danger")
    finally:
        conn.close()

    return redirect(url_for("admin_page"))

if __name__ == "__main__":
    app.run(debug=True, port=5000)