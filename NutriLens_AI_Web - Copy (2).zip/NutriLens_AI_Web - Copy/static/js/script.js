document.addEventListener('DOMContentLoaded', function() {
    
    // File upload preview & drag-and-drop
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const ingredientTextArea = document.getElementById('ingredientTextArea');
    const productNameInput = document.getElementById('productNameInput');

    if (dropzone && fileInput) {
        dropzone.addEventListener('click', () => fileInput.click());

        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.style.background = '#E8F7ED';
        });

        dropzone.addEventListener('dragleave', () => {
            dropzone.style.background = '#F4FBF6';
        });

        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.style.background = '#F4FBF6';
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                updateFileDisplay();
            }
        });

        fileInput.addEventListener('change', updateFileDisplay);

        function updateFileDisplay() {
            if (fileInput.files.length > 0) {
                fileNameDisplay.textContent = 'Selected: ' + fileInput.files[0].name;
                fileNameDisplay.style.color = '#2E7D32';
                fileNameDisplay.style.fontWeight = 'bold';
            }
        }
    }

    // Sample product selector auto-fill
    const sampleCards = document.querySelectorAll('.sample-card');
    if (sampleCards.length > 0) {
        sampleCards.forEach(card => {
            card.addEventListener('click', function() {
                const pname = this.getAttribute('data-pname');
                const text = this.getAttribute('data-text');
                
                if (productNameInput) productNameInput.value = pname;
                if (ingredientTextArea) ingredientTextArea.value = text;

                // Visual highlight feedback
                sampleCards.forEach(c => c.style.borderColor = '#E2E8F0');
                this.style.borderColor = '#2E7D32';
            });
        });
    }

});

// Print or Save PDF function for Analysis Results
function printResultReport() {
    window.print();
}
